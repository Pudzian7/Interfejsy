﻿using Interfejsy;
using System;

namespace MyApp // Note: actual namespace depends on the project name.
{
    internal class Program
    { 

        static void Main(string[] args)
        {
     

        List<Szkola> szkoly = new List<Szkola>()
{
    new Szkola("Szkoła Podstawowa nr 1", "ul. Szkolna 1, Radom", 200),
    new Szkola("Szkoła Podstawowa nr 2", "ul. Szkolna 2, Radom", 300),
    new Szkola("Szkoła Podstawowa nr 3", "ul. Szkolna 3, Radom", 100),
    new Szkola("Szkoła Podstawowa nr 4", "ul. Szkolna 4, Radom", 150),
    new Szkola("Szkoła Podstawowa nr 5", "ul. Szkolna 5, Radom", 50)
};

            Console.WriteLine("Szkoly przed sortowaniem:");
            foreach (Szkola szkola in szkoly)
            {
                szkola.Wypisz();
            }

            szkoly.Sort();

            Console.WriteLine("Szkoly po sortowaniu:");
            foreach (Szkola szkola in szkoly)
            {
                szkola.Wypisz();
            }

        }
    }
}