﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static MyApp.Program;

namespace Interfejsy
{
    public class Napis : IWypisywanie
    {
        public string Tekst { get; set; }

        public void WielkieLitery()
        {
            Tekst = Tekst.ToUpper();
        }

        public void Wypisz()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(Tekst);
            Console.ResetColor();
        }
    }

}
