﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static MyApp.Program;

namespace Interfejsy
{
    public class Szkola : IWypisywanie, IComparable<Szkola>
    {
        public string Nazwa { get; set; }
        public string Adres { get; set; }
        public int IloscUczniow { get; set; }

        public Szkola(string nazwa, string adres, int iloscUczniow)
        {
            Nazwa = nazwa;
            Adres = adres;
            IloscUczniow = iloscUczniow;
        }

        public int CompareTo(Szkola other)
        {
            return this.IloscUczniow.CompareTo(other.IloscUczniow);
        }

        public void Wypisz()
        {
            string ramka = new string('-', Math.Max(Nazwa.Length, Adres.Length) + 4);
            Console.WriteLine(ramka);
            Console.WriteLine($"|  {Nazwa} |");
            Console.WriteLine($"|  {Adres}   |");
            Console.WriteLine(ramka);
        }
    }


}
